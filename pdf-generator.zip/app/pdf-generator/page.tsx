"use client"

import dynamic from "next/dynamic"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button" // Assuming shadcn button is available

// Dynamically import PDFViewer and PDFDownloadLink to ensure they are client-side only
// This is crucial because @react-pdf/renderer relies on browser APIs.
const PDFViewer = dynamic(() => import("@react-pdf/renderer").then((mod) => mod.PDFViewer), { ssr: false })
const PDFDownloadLink = dynamic(() => import("@react-pdf/renderer").then((mod) => mod.PDFDownloadLink), { ssr: false })

// Import the PDF component
import MotorInsuranceCertificate from "@/components/motor-insurance-certificate"

export default function PdfGeneratorPage() {
  const [isClient, setIsClient] = useState(false)

  // Ensure client-side components only render after mounting
  useEffect(() => {
    setIsClient(true)
  }, [])

  if (!isClient) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Loading PDF viewer...</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-100">
      <h1 className="text-2xl font-bold mb-6">Motor Insurance Certificate</h1>
      <div className="mb-6">
        <PDFDownloadLink document={<MotorInsuranceCertificate />} fileName="motor-insurance-certificate.pdf">
          {({ loading }) => <Button disabled={loading}>{loading ? "Generating PDF..." : "Download PDF"}</Button>}
        </PDFDownloadLink>
      </div>
      <div className="w-full h-[80vh] max-w-4xl border border-gray-300 rounded-lg overflow-hidden shadow-lg">
        <PDFViewer width="100%" height="100%">
          <MotorInsuranceCertificate />
        </PDFViewer>
      </div>
    </div>
  )
}
